package sevenui;

import javax.swing.*;

// 임시 결제 클래스
public class Pay extends JFrame {

	public Pay() {
		
		setTitle("결제 창");
		
		setBounds(300,300,300,300);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

}
