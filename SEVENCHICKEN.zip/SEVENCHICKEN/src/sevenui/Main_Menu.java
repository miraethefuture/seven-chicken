package sevenui;

import javax.swing.*;

// 임시 실행 클래스
public class Main_Menu extends JFrame{

	public static void main(String[] args) {

		new Menu();
		
	}

}
