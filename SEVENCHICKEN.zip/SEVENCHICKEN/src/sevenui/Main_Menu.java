package sevenui;

public class Main_Menu {

	public static void main(String[] args) {

		new Menu();
		
	}

}
