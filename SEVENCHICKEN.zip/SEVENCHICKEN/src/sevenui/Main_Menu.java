package sevenui;

import javax.swing.*;

public class Main_Menu extends JFrame{

	public static void main(String[] args) {

		new Menu();
		
	}

}
