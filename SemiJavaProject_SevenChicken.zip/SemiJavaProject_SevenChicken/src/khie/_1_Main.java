package khie;

public class _1_Main {

	public static void main(String[] args) {
		
		new _2_Log();

	}

}